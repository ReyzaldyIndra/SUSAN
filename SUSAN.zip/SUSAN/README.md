# SUSAN
A BPJS Chatbot developed with Python and Golang. Used for thesis project of it's contributors.
