package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"time"
	//"log"
	"net/http"
	"github.com/gorilla/sessions"
)

var stores = sessions.NewCookieStore([]byte(os.Getenv("SESSION_KEY")))

func MyHandler(w http.ResponseWriter, r *http.Request) {
	// Get a session. Get() always returns a session, even if empty.
	session, err := store.Get(r, "session-name")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Set some session values.
	session.Values["foo"] = "bar"
	session.Values[42] = 43
	// Save it before we write to the response/return from the handler.
	err = session.Save(r, w)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

var (
	key = []byte("bec47d015c5fc6a951089edbe0221c02")
	store = sessions.NewCookieStore(key)
)

func secret(w http.ResponseWriter, r *http.Request) {
	//cookieName := "ktp"
	session, _ := store.Get(r, "ktp")
	log.Println(session.Values["ktp"])
	//log.Println("woe", p)
	c, err := r.Cookie("ktp")
	//log.Println(c(cookieName)
	if err != nil {
		w.Write([]byte("error in reading cookie : " + err.Error() + "\n"))
	} else {
		value := c.Value
		log.Println("val", value)
		w.Write([]byte("cookie has : " + value + "\n"))
	}
	//session, _ := store.Get(r, "ktp")
	//c:= &http.Cookie{}
	//cookieName := "ktp"
	//log.Println("init c value", c.Value)
	//log.Println( r.Cookie(cookieName))
	// Check if user is authenticated
	//if storedCookie, _ := r.Cookie(cookieName); storedCookie != nil {
		//c = storedCookie
		//log.Println(r.Cookie(c.Value))
		//log.Println("c Value",	c.Value)
		//log.Println("storedCookie Value", storedCookie.Value)
		//if c.Value == storedCookie.Value {
		//	log.Println("cookie value is the same")
		//	return
		//} else {
		//	log.Println("cookie value is different")
		//	return
		//}
		//log.Println("storedCookie", c)
		//session.Values["authenticated"] = true
		//session.Save(r, w)
	//} else {
	//	http.Error(w, "Forbidden", http.StatusForbidden)
	//	return
	//}
	//if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
	//	http.Error(w, "Forbidden", http.StatusForbidden)
	//	return
	//}

	// Print secret message
	//fmt.Fprintln(w, "The cake is a lie!")
}

func login(w http.ResponseWriter, r *http.Request) {
	//session, _ := store.Get(r, "ktp")
	var detail yinganDetail
	expire := time.Now().AddDate(0,0,1)

	c:= &http.Cookie{}
	cookieName := "ktp"

	if storedCookie, _ := r.Cookie(cookieName); storedCookie != nil {
		c = storedCookie
		//session.Values["authenticated"] = true
		//session.Save(r, w)
	} else {
		userLineId := "U171ee9ba7adebdc9b2d6c899de5084a1"
		reqBody := yinganRequest{
			UserLineId : userLineId,
		}
		reqBytes,err := json.Marshal(reqBody)
		req, err := http.NewRequest("GET", fmt.Sprintf("https://susan-service.herokuapp.com/ktp/"), bytes.NewBuffer(reqBytes))
		if err != nil {

			//return yinganDetail{}, err
		}
		req.Header.Set("Content-Type","application/json")
		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			fmt.Fprintln(w, resp)
			//return yinganDetail{},err
		} else {
			defer resp.Body.Close()
			if err := json.NewDecoder(resp.Body).Decode(&detail); err != nil {
				log.Println("INI RESULT KTP err: ",detail.Ktp)
				log.Println("INI RESULT LineID err: ",detail.LineID)
				c.Name = cookieName
				c.Value = detail.Ktp
				c.Expires = expire
				http.SetCookie(w,c)
			} else {
				log.Println("INI RESULT KTP else: ",detail.Ktp)
				log.Println("INI RESULT LineID else: ",detail.LineID)
				c.Name = cookieName
				c.Value = detail.Ktp
				c.Expires = expire
				http.SetCookie(w,c)
				//session.Values["authenticated"] = true
				//session.Save(r, w)
				//session.Values["ktp"] = detail.Ktp
				//session.Save(r,w)
				//return detail,nil
			}
		}
	}

	// Authentication goes here
	// ...


	//cookie := http.Cookie{
	//	Name: "ktp",
	//	Value: detail.Ktp,
	//	Expires: expire,
	//}
	//http.SetCookie(w, &cookie)
	// Set user as authenticated
	//session.Values["authenticated"] = true
	//session.Save(r, w)
	//return detail, nil
}



func logout(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "ktp")

	// Revoke users authentication
	session.Values["authenticated"] = false
	session.Save(r, w)
}

func main() {
	http.HandleFunc("/secret", secret)
	http.HandleFunc("/login", login)
	http.HandleFunc("/logout", logout)

	http.ListenAndServe(":8080", nil)
}

type yinganRequest struct {
	UserLineId string `json:"userLineId"`
}

type yinganDetail struct {
	LineID string `json:"userLineId"`
	Ktp string `json:"ktp"`
}
