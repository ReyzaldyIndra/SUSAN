from django.apps import AppConfig


class BlackboardConfig(AppConfig):
    name = 'blackboard'
